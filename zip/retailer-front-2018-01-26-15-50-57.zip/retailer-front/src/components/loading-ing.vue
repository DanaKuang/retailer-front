<template>
	<div class="loading">
		<span class="theme-bg-color_lighter"></span>
	    <span class="theme-bg-color_lighter"></span>
	    <span class="theme-bg-color_lighter"></span>
	    <span class="theme-bg-color_lighter"></span>
	    <span class="theme-bg-color_lighter"></span>
	</div>
</template>
<script>
	export default {
		name: 'loading-vue'
	}
</script>